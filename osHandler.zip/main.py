import jsonBuilder
import sys_handler
from flask import Flask, render_template, redirect, request, session, jsonify, send_file, send_from_directory
import os

app = Flask(__name__)
current_url = "http://127.0.0.1:5000"

@app.route("/api_index")
def api_index():
    result = {"location" : current_url + "/get_location",
              "get_files": current_url + "/get_files",
              "get_folders": current_url + "/get_folders",
              "move back" : current_url + "/move_back"}
    return jsonify(result)

@app.route("/")
def index():
    return render_template("index2.html")


@app.route("/move_to/<foldername>")
def move_into_folder(foldername):
    print(foldername)
    sys_handler.move_into_folder(foldername)
    return jsonBuilder.get_location()

@app.route("/get_location")
def get_location():
    return jsonBuilder.get_location()

@app.route("/get_files")
def get_files():
    return jsonBuilder.get_files()

@app.route("/download_file/<path>")
def DownloadLogFile (path):
    realpath = path.replace("!", "/")
    print("reaplath is = " + realpath)
    print(os.getcwd())
    try:
        return send_from_directory(os.getcwd(), realpath, as_attachment=True)
    except Exception as e:
        print(e)

@app.route("/get_folders")
def get_folders():
    return jsonBuilder.get_folders()


@app.route("/move_back")
def move_back():
    sys_handler.move_back()
    return jsonBuilder.get_location()


if __name__ == "__main__":
    app.secret_key = "app_magic"  # Change the content of this string
    app.run(
        host = '0.0.0.0',
        debug=True,
        port=5000
    )
